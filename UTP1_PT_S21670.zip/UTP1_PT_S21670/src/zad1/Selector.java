/**
 *
 *  @author Pyrzak Tomasz S21670
 *
 */

package zad1;


public interface Selector<T> {
    public <T> boolean select(T t);
}