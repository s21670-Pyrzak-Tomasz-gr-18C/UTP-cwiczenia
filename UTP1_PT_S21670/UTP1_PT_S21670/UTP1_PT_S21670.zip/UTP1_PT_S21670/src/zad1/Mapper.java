/**
 *
 *  @author Pyrzak Tomasz S21670
 *
 */

package zad1;


public interface Mapper<T,R>{
    public <R> Integer map(T e);
}

